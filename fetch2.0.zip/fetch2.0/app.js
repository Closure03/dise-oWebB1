import  {DataApi} from "./data.js";
//instanciar objeto, crear objeto
let myData = new DataApi();
const allData = myData.getData();
console.log(allData);
console.log(mydata.getInfocompleta());
//console.log(myData.url);
//console.log(myData.infoCompleta);
